
  # zabka_app

  This is a code bundle for zabka_app. The original project is available at https://www.figma.com/design/RFT8cdP9v08hLcIODzqoRE/zabka_app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  